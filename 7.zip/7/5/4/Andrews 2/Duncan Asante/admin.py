
from flask import Blueprint, render_template

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin/requests')
def view_requests():
    requests = [
        {'name': 'John Doe', 'service': 'Transcript', 'status': 'Pending'},
        {'name': 'Jane Smith', 'service': 'Clearance', 'status': 'Approved'}
    ]
    return render_template('admin_requests.html', requests=requests)

@admin_bp.route('/admin/process')
def process_submissions():
    pending = [
        {'name': 'John Doe', 'type': 'Transcript'},
        {'name': 'Emily Stone', 'type': 'Clearance'}
    ]
    return render_template('admin_process.html', submissions=pending)

@admin_bp.route('/admin/users')
def manage_users():
    users = ['admin@example.com', 'user1@domain.com']
    return render_template('admin_users.html', users=users)

@admin_bp.route('/admin/manage-requests')
def manage_requests():
    requests = [
        {'id': 1, 'type': 'Transcript', 'status': 'Pending'},
        {'id': 2, 'type': 'Clearance', 'status': 'Approved'}
    ]
    return render_template('admin_manage_requests.html', requests=requests)
