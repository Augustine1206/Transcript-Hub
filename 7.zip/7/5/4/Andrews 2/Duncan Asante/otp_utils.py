
import random
import string
from flask_mail import Message
from mailer import mail

otp_store = {}

def generate_otp():
    return ''.join(random.choices(string.digits, k=6))

def send_otp_email(email, otp):
    msg = Message('Your OTP Verification Code',
                  sender='noreply@transcripthub.com',
                  recipients=[email])
    msg.body = f'Your OTP code is: {otp}. It is valid for 10 minutes.'
    mail.send(msg)

def store_otp(email, otp):
    otp_store[email] = otp

def validate_otp(email, user_otp):
    return otp_store.get(email) == user_otp
