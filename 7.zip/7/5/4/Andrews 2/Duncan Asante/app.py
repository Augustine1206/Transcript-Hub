
from flask import Flask, render_template, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from mailer import init_mail, mail
from models import User
from routes.auth import auth
from routes.user import user
from routes.admin import admin
from routes.pdf import pdf_bp
from routes.verify import verify_bp
from routes.payment import payment_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'thisissecret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

init_mail(app)
mail.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Register blueprints
app.register_blueprint(auth)
app.register_blueprint(user)
app.register_blueprint(admin)
app.register_blueprint(pdf_bp)
app.register_blueprint(verify_bp)
app.register_blueprint(payment_bp)

# Homepage route
@app.route('/')
def homepage():
    return render_template('welcome.html')

# Admin login logic
# Clearance form logic
@app.route('/submit-clearance', methods=['POST'])
def submit_clearance():
    student_id = request.form.get('student_id')
    dob = request.form.get('dob')
    faculty = request.form.get('faculty')
    return f"Clearance for {student_id} submitted successfully!"

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        if email == 'admin@example.com' and password == 'admin123':
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template('admin-login.html', error='Invalid credentials')
    return render_template('admin-login.html')
