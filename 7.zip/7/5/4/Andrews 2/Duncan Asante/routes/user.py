
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models import db, Request

user = Blueprint('user', __name__)

@user.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    if request.method == 'POST':
        new_request = Request(
            user_id=current_user.id,
            service_type=request.form['service_type'],
            student_id=request.form['student_id'],
            dob=request.form['dob'],
            years_from=request.form['years_from'],
            years_to=request.form['years_to'],
            faculty=request.form['faculty'],
            department=request.form['department'],
            degree=request.form['degree'],
            status="Pending"
        )
        db.session.add(new_request)
        db.session.commit()
        flash("Request submitted.")
        return redirect(url_for('user.dashboard'))

    requests = Request.query.filter_by(user_id=current_user.id).all()
    return render_template('dashboard.html', user=current_user, requests=requests)
