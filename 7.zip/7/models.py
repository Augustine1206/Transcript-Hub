
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Request(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))
    email = db.Column(db.String(120))
    phone = db.Column(db.String(50))
    student_id = db.Column(db.String(50))
    department = db.Column(db.String(100))
    degree = db.Column(db.String(100))
    years_from = db.Column(db.String(10))
    years_to = db.Column(db.String(10))
    request_type = db.Column(db.String(50))  # 'Transcript' or 'Clearance'
    payment_status = db.Column(db.String(20), default="Pending")
    status = db.Column(db.String(20), default="Pending")
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Request {self.name}, {self.request_type}>'
