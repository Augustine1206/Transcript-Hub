from flask import Flask, render_template, request, redirect, flash, url_for
from models import db, Request

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///transcripts.db'
app.config['SECRET_KEY'] = 'secret'
db.init_app(app)

@app.before_first_request
def create_tables():
    db.create_all()

@app.route("/")
def home():
    return render_template("welcome.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/submit-request", methods=["POST"])
def submit_request():
    req = Request(
        name=request.form['name'],
        email=request.form['email'],
        phone=request.form['phone'],
        student_id=request.form['student_id'],
        department=request.form['department'],
        degree=request.form['degree'],
        years_from=request.form['years_from'],
        years_to=request.form['years_to'],
        request_type="Transcript"
    )
    db.session.add(req)
    db.session.commit()
    flash("Request submitted successfully.")
    return redirect(url_for("dashboard"))

@app.route("/submit-clearance", methods=["POST"])
def submit_clearance():
    req = Request(
        name=request.form['name'],
        email=request.form['email'],
        phone=request.form['phone'],
        student_id=request.form['student_id'],
        department=request.form['department'],
        degree=request.form['degree'],
        years_from=request.form['years_from'],
        years_to=request.form['years_to'],
        request_type="Clearance"
    )
    db.session.add(req)
    db.session.commit()
    flash("Clearance request submitted successfully.")
    return redirect(url_for("dashboard"))

@app.route("/admin-dashboard")
def admin_dashboard():
    requests = Request.query.order_by(Request.submitted_at.desc()).all()
    return render_template("admin_dashboard.html", requests=requests)

if __name__ == "__main__":
    app.run(debug=True)
